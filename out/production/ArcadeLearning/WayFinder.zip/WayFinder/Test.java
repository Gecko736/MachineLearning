package WayFinder;

public class Test {
    public static void main(String[] args) {
        Data[] data = new Data[29];
        int j = 0;
        for (int i = -10; i < 10; i++) {
            double[] input = {i};
            double[] output = {(i * 10) + 5};
            data[j++] = new Data(input, output);
        }
        for (int i = 11; i < 20; i++) {
            double[] input = {i};
            double[] output = {(i * 10) + 5};
            data[j++] = new Data(input, output);
        }
        Brain.MAX = 205;
        Brain.MIN = -95;

        int[] layers = {1, 3, 1};
        Brain brain = new Brain(layers);

        double[] input = {10};
        System.out.println("Input: 10.0 | Desired output:105.0 | Output: " + brain.output(input)[0]);

        brain.print();
        System.out.println();
        brain.print(input);
        System.out.println();

        brain.backpropagate(data, 5.0);
        System.out.println();

        brain.print();
        System.out.println();
        brain.print(input);
        System.out.println("\nInput: 10.0 | Desired output:105.0 | Output: " + brain.output(input)[0]);
        for (Data d : data) {
            System.out.printf("Input:%5.1f | Desired output:%5.1f | Output: %-25s\n",
                    d.input[0], d.output[0], brain.output(d.input)[0]);
        }
    }
}